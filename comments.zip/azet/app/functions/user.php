<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
 
class User {

	private $conn;
	private $configuration;

	/**
	 * Constructor
	 *
	 */
	public function __construct($conn, $configuration){
		
		$this->configuration = $configuration;
		$this->conn = $conn;	
			
	}	


function signUp (){
	$securekey = $this->configuration['securekey'];
	$name 	= getVar('name', '');
	$nameSafe = sanitize($name);
	$pass 	= getVar('pass', '');
	$passSafe = sanitize($pass);
	$pass2 = getVar('pass2', '');
	$pass2Safe 	= sanitize($pass);
	$error = false;
	//check name and password lenhth
	if(strlen($name)<4) {
		$_SESSION['alert'][] = _lng("Username ERROR! Username must be at least 4 characters!");
		$error = true;
		}
	if(strlen($pass)<8 OR strlen($pass2)<8) {
		$_SESSION['alert'][] = _lng("Password ERROR! Password must be at least 8 characters!");
		$error = true;
		}	
	//check if HTML tangs used - hack error
	if($name!=$nameSafe) {
		$_SESSION['alert'][] = _lng("Username ERROR! You can use only letters and digits!");
		$error = true;
		}	
	if($pass!=$passSafe OR $pass2!=$pass2Safe) {
		$_SESSION['alert'][] = _lng("Password ERROR! You can use only letters and digits!");
		$error = true;
		}	
	//check if passwors are identical
	if($pass!=$pass2) {
		$_SESSION['alert'][] = _lng("Password ERROR! Entered passwords are not identical!");
		$error = true;
		}	
	if($error) return false;
	
	// escape variables for security
	$name = mysqli_real_escape_string($this->conn, $name);
	$pass = mysqli_real_escape_string($this->conn, $pass);
	$pass = $securekey.$pass;
	$hash = password_hash($pass, PASSWORD_DEFAULT);
	$sql = "INSERT INTO ".$this->configuration['db']['dbprefix']."users (name, password) VALUES ('".$name."','".$hash."')";
	if(!mysqli_query($this->conn,$sql)){
		$_SESSION['alert'][] = _lng("User with name").$name._lng("already exists!");
		return false;
		}
	$_SESSION['note'][] = _lng("User successfuly registered. Please login with your credentials.");
	return true;
	
}

function authUser ($task='') {
	$user = $this::getUser();
	$securekey = $this->configuration['securekey'];
	// return if user is already logged in or task is not to login the new user
	if($user->isLoggedIn OR $task!='login') {
		return true;
		}
	else{
		
	$name 	= getVar('name', '');
	$pass 	= getVar('pass', '');
	$pass = $securekey.$pass;
	$error = false;
	// escape variables for security
	$name = mysqli_real_escape_string($this->conn, $name);
	
	$sql = "SELECT * FROM ".$this->configuration['db']['dbprefix']."users WHERE name='".$name."'";
	$result = mysqli_query($this->conn,$sql);
	$row=mysqli_fetch_assoc($result);
	$hash = $row['password'];
	if (password_verify($pass, $hash)) {
		unset($_SESSION["user"]);
		$user = new stdClass();
		$user->id = $row['id'];
		$user->name = $row['name'];
		$user->isLoggedIn = true;
		$user->isAdmin = $row['admin'];
		$user->canAddComment = true;
		$_SESSION["user"] = $user;
		return true;
	}
	else {
		$_SESSION['alert'][] = _lng("Username or Password is incorrect, you are not logged in!");
		return false;
	}

	}
	}

static function getUser(){
	
	if(!isset($_SESSION["user"])){
		$user = new stdClass();
		$user->id = false;
		$user->name = '';
		$user->isLoggedIn = false;
		$user->isAdmin = false;
		$user->canAddComment = false;
	}
	else $user = $_SESSION["user"];
	
	return $user;
}

public function logOut () {
	unset($_SESSION["user"]);
	}
}

?>

