<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
 
class Comments {

	private $conn;
	private $configuration;

	/**
	 * Constructor
	 *
	 */
	public function __construct($conn, $configuration){
		
		$this->configuration = $configuration;
		$this->conn = $conn;	
			
	}	


public function getComments(){
	
	$sql = "SELECT * FROM ".$this->configuration['db']['dbprefix']."comments ORDER BY date DESC LIMIT 10";
	$result = mysqli_query($this->conn,$sql);
	$row=mysqli_fetch_assoc($result);
	
	}
}

?>

