<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access 
 defined('_EXEC') or die;
 
 session_start();
 
 //load configuration file
 require_once 'config/configuration.php';
 
 //load basic functions
 require_once 'app/functions/functions.php';
 
 //load basic MVC classes
 require_once 'app/controllers/controller.php';
 require_once 'app/models/model.php';
 require_once 'app/views/view.php';
 
  //load class to handle users
  require_once 'app/functions/user.php';
 
 //init language file
 initLang($configuration['language']);
 
 //load basic class for application
 require_once 'app/application.php'; 
 
 $app = new Application($configuration);
 $app-> display();

?>

