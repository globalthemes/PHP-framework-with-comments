<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;


function getVar($varname, $default='', $method='REQUEST') {
	
	$var = $default;
	
	switch ($method) {
    case 'GET':
        if(isset ($_GET[$varname])){
			$var = $_GET[$varname];
			};
        break;
    case 'POST':
         if(isset ($_POST[$varname])){
			$var = $_POST[$varname];
			};
        break;
    default:
         if(isset ($_REQUEST[$varname])){
			$var = $_REQUEST[$varname];
			};
        break;
    }

	return $var;
	
	}
	
function loadLayout($template, $data) {

	echo "<!DOCTYPE html>\n";
	echo '<html lang="en">';
	echo "\n";
	require_once 'app/views/tmpl/header.php';
	echo "<body>\n";
	alerts();
	require_once 'app/views/tmpl/navbar.php';
	require_once 'app/views/tmpl/login.php';
	require_once 'app/views/tmpl/'.$template.'.php';
	require_once 'app/views/tmpl/footer.php';
	echo "</body>\n</html>";	
	
	}	

function alerts () {

	if(isset($_SESSION['alert']) && count($_SESSION['alert']>0)){
		$alert='';
		foreach ($_SESSION['alert'] as $key => $value) {
			$alert.='<p>'.$value.'</p>';
		}
		echo '<div class="container alert alert-danger" role="alert">'.$alert.'</div>';
		unset($_SESSION['alert']);
	}
	if(isset($_SESSION['note']) && count($_SESSION['note']>0)){
		$alert='';
		foreach ($_SESSION['note'] as $key => $value) {
			$alert.='<p>'.$value.'</p>';
		}
		echo '<div class="container alert alert-success" role="alert">'.$alert.'</div>';
		unset($_SESSION['note']);
	}	
	
	}

function initLang($lang){
	//if(!isset($_SESSION["lang"])){
		
	    $file = 'lang/'.$lang.'.php';
		if(file_exists($file)) {
		require_once $file;
		$_SESSION["lang"] = $language;
		
	}
	
	//} 
	} 

function _lng($text) {
	
	if(isset($_SESSION["lang"][$text])) {
		return $_SESSION["lang"][$text];
		}
		else{
			return $text;
			}
	
	}


function dbConnect ($db){

	// Create connection
		//$conn = mysqli_connect($db['host'], $db['user'], $db['password']);

		$conn = new mysqli($db['host'], $db['user'], $db['password'], $db['db']);
		// Check connection
		if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
	//	if ($conn->connect_error) {
	//		die("Connection failed: " . $conn->connect_error);
	//	} 
	
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	$conn->set_charset("utf8");
	return $conn;
	}

	
	
function sanitize ($string) {
	//remove  tags, remove  special characters and remove characters with ASCII value < 32 
	$string = filter_var($string, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW);
	//remove  tags, remove  special characters and remove characters with ASCII value > 127
	$string = filter_var($string, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
	return $string;
	}	
?>

