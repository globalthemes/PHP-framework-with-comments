<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
class Controller extends BaseController {

	/**
	 * Constructor
	 *
	 */
	public function __construct($db,$view='home', $task='', $configuration){
		parent::__construct($db,$view, $task, $configuration);				
	}	
	/**
	 * Load MVC modelled classes and render the content 
	 *
	 * @return	html	HTML code
	 * @since	1.0.1
	 */
	public function Render () {
		
		//add comment if user is logged in
		if($this->task=='add' && $this->user->isLoggedIn) {
				$this->model->addComment();
			}
		//remove comment if ser is admin
		if($this->task=='delete' && $this->user->isAdmin) {
				$this->model->removeComment();
			}		
		
		
		if($this->modelExists && $this->viewExists){
		$data = $this->model->getData(); 

		if($data) {	
			// check user rule and if logged in
			if($this->user->isLoggedIn) {
				if($this->user->isAdmin) {
					//load template for administrator
					$layout = 'home_admin';
					}
					else{
						//load template for logged in user
						$layout = 'home_user';
						}
				}
			else{
				//load public template
				$layout = 'home_public';
				}
				
			$view = new View($data, $layout);
			$view->Render();
						 
		}		
			}
			else{
				echo "View ".loadLayout($template)." cannot be rendered </br>";
				}
	}

}
?>

