<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
class Controller extends BaseController {

	/**
	 * Constructor
	 *
	 */
	public function __construct($db,$view='signup', $task=''){
		parent::__construct($db,$view, $task);				
	}	
	/**
	 * Load MVC modelled classes and render the content 
	 *
	 * @return	html	HTML code
	 * @since	1.0.1
	 */
	public function Render () {
		if($this->modelExists && $this->viewExists){

		$data = $this->model->getData(); 

		$layout = 'signup';
			
			$view = new View($data, $layout);
			$view->Render();
		
			}
			else{
				echo "View cannot be rendered </br>";
				}



	}

}
?>

