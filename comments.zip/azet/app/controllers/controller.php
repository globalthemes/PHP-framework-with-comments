<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
class BaseController {

	protected $task;
	protected $model;
	protected $modelExists;
	protected $view;
	protected $viewExists;
	protected $user;
	protected $configuration;
	protected $conn;

	/**
	 * Constructor
	 *
	 */
	public function __construct($conn, $view='home', $task='', $configuration){
		$this->conn		= $conn;
		$this->view		= $view;
		$this->task		= $task;
		$this->configuration = $configuration;
		$this->user = User::getUser();

		
		//load MVC classes based on the layout
		//model
		$this->modelExists = 'app/models/'.$view.'.php';
		if(file_exists($this->modelExists)) {
			 require_once $this->modelExists;			
			}
			else{
				$this->modelExists	= false;
				}
		//view
		$this->viewExists = 'app/views/'.$view.'.php';
		if(file_exists($this->viewExists)) {
			 require_once $this->viewExists;		
			}
			else{
				$this->viewExists	= false;
				}		
		//initialize model
		if($this->modelExists && $this->viewExists){
			$this->model = new Model($conn, $this->task, $this->configuration);
			}
			
		// echo error messeges if exists
		$this-> checkError();		
		
	}	
	/**
	 * Load MVC modelled classes and render the content 
	 *
	 * @return	html	HTML code
	 * @since	1.0.1
	 */
	public function Render () {

	}

	public function checkError(){
		
		if(!$this->modelExists) $_SESSION['alert'][] = _lng("Error loading MVC model class for view:").$this->view;
		if(!$this->viewExists)  $_SESSION['alert'][] = _lng("Error loading MVC view class for view:").$this->view;	
		}

}
?>

