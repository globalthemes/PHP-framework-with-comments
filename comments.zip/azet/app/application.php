<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
 
class Application {

	private $layout;
	private $task;
	private $render;
	private $conn;
	private $configuration;
	private $user;

	/**
	 * Constructor
	 *
	 */
	public function __construct($configuration){
		
		$this->configuration = $configuration;
		$this->view 	= getVar('view', 'home');
		$this->task 	= getVar('task', '');
		$this->controller	= true;
		$this->conn = dbConnect($configuration['db']);
		$this->user = new User($this->conn, $this->configuration);

	}	
	/**
	 * Load MVC modelled classes and render the content 
	 *
	 * @return	html	HTML code
	 * @since	1.0.1
	 */
	public function display () {
	
		//check if signup request received
		if($this->task=='signup') {
			if(!$this->user->signUp()){
				$this->view = 'signup';
				}
			}

		//check if logout request received
		if($this->task=='logout') {
			if(!$this->user->logOut()){
				$this->view = 'home';
				}
			}
		//authentificate the user	
		$this->user->authUser($this->task);
		
		//load MVC controller class based on the layout
		$controller = 'app/controllers/'.$this->view.'.php';
		if(file_exists($controller)) {
			 require_once $controller;			
			}
			else{
				$this->controller	= false;
				}			
		
		if($this->controller){
			$controller = new Controller($this->conn, $this->view, $this->task, $this->configuration);
			$controller->Render();
			}
			else{
				echo "Error loading MVC controller class </br>";
				}
	}

}

?>

