<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;

class BaseModel {

	protected $data;
	protected $task;
	protected $user;
	protected $db;
	
	/**
	 * Constructor
	 *
	 * @since	1.0.1
	 */
	public function __construct($conn, $task, $configuration){
		
		$this->configuration = $configuration;
		$this->conn = $conn;
		$this->task = $task;
		$this->user = User::getUser();		
	}	

	public function GetData () {
			return true;
		}
	
	

}

?>

