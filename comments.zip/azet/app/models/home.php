<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;

class Model extends BaseModel{

	
	/**
	 * Constructor
	 *
	 * @since	1.0.1
	 */
	public function __construct($conn, $task, $configuration){
		
	parent::__construct($conn, $task, $configuration);	
			
	}	

	public function GetData () {
		$data = array();
		$sql = "SELECT u.name, c.id, c.title, c.content, c.date FROM ".$this->configuration['db']['dbprefix']."comments AS c INNER JOIN ".$this->configuration['db']['dbprefix']."users AS u ON c.iduser=u.id ORDER BY id DESC LIMIT 10";
		$result = $this->conn->query($sql);
		
		while($row = $result->fetch_assoc()) {
			$data[] = $row;
		}

		return $data;
			}
			
	public function addComment (){
		
	$title 	= getVar('title', '');
	$title = sanitize($title);
	$comment 	= getVar('comment', '');
	$comment = sanitize($comment);		
		
	//check if user can add the comment
	$canAdd=true;
	//check similarity
	$sql = "SELECT * FROM ".$this->configuration['db']['dbprefix']."comments WHERE iduser=".$this->user->id;
	$result = $this->conn->query($sql);

		while($row = $result->fetch_assoc()) {
			$length=floor(strlen($row['content']));	
			if(similar_text($comment,$row['content'])/$length>0.9){
				$canAdd=false;
				$_SESSION['alert'][] = _lng("Cannot add similar comments!");
				}	
				
		}
	//check max comments per a day
	$sql = "SELECT * FROM ".$this->configuration['db']['dbprefix']."comments WHERE date=CURDATE() AND iduser=".$this->user->id;
	$result = $this->conn->query($sql);
	$comments=0;
		while($row = $result->fetch_assoc()) {
			$comments++;
			if($comments==5){
				$canAdd=false;
				$_SESSION['alert'][] = _lng("Cannot add more comments!");
				}
	
				
		}
	
	if($canAdd) {

		// escape variables for security
		$comment = mysqli_real_escape_string($this->conn, $comment);
		$title = mysqli_real_escape_string($this->conn, $title);

		$sql = "INSERT INTO ".$this->configuration['db']['dbprefix']."comments (iduser, title, content, date) VALUES ('".$this->user->id."', '".$title."','".$comment."', CURDATE())";
		if(!mysqli_query($this->conn,$sql)){
			$_SESSION['alert'][] = _lng("Error writing the comment!");
			return false;
			}
		$_SESSION['note'][] = _lng("Comment successfuly added.");
		return true;		
	}	
	}	
	
	public function removeComment (){
		$id 	= getVar('id', '');
		$id = sanitize($id);	
		$sql = "DELETE FROM ".$this->configuration['db']['dbprefix']."comments WHERE id=".$id;
		$result = $this->conn->query($sql);		
		
	}
}

?>

