<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */

 //prevent direct access
 defined('_EXEC') or exit;
 ?>

<!-- Page Content -->		  
<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<h1><?php echo _lng('Default home site'); ?></h1>
			<p><?php echo _lng('Public access'); ?></p>	
			<?php 
				$html="";
				foreach ($data as $row) {
					$html.='<div class="comment">
							<p class="user"><span class="date">'.$row['date'].'</span><span class="name"> '.$row['name'].'</span></p>
							<p class="title">'.$row['title'].'</p>
							<p class="content">'.$row['content'].'</p>
							</div>
					';
				}

			echo $html;
			 ?>		
		</div>
	</div>
</div>


