<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or exit;
 ?>
<!-- Page Content -->
<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<div class="loginmodal-container">
				<h1><?php echo _lng('Signup'); ?></h1><br>
				  <form action="index.php" method="post">
					<input type="text" name="name" placeholder="<?php echo _lng('Username'); ?>"  >
					<input type="password" name="pass" placeholder="<?php echo _lng('Password'); ?>" >
					<input type="password" name="pass2" placeholder="<?php echo _lng('Password confirm'); ?>" >
					<input type="submit" name="login" class="login loginmodal-submit" value="<?php echo _lng('Signup'); ?>" >
					<input type="hidden" name="view" value="home">
					<input type="hidden" name="task" value="signup">
				  </form>
			</div>
		</div>
	</div>
</div>

