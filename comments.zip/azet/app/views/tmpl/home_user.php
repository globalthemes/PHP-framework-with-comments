<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or exit;
 ?>
<!-- Page Content -->
<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<h1><?php echo _lng('Default home site'); ?></h1>
			<p><?php echo _lng('Non Administrator User can access'); ?></p>
			<?php 
				$html="";
				foreach ($data as $row) {
					$html.='<div class="comment">
							<p class="user"><span class="date">'.$row['date'].'</span><span class="name"> '.$row['name'].'</span></p>
							<p class="title">'.$row['title'].'</p>
							<p class="content">'.$row['content'].'</p>
							</div>
					';
				}

			echo $html;
			 ?>	

		</div>
	</div>
</div>

<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<h2><?php echo _lng('Add new comment'); ?></h2>
			<div class="loginmodal-container" style="max-width:100%;">
			  <form action="index.php" method="post" id="addcomment">
				<input type="text" name="title" placeholder="<?php echo _lng('Title'); ?>"  >
				<textarea name="comment" form="addcomment" style="width:100%;background-color: #ffffff;"></textarea>
				<input type="submit" name="login" class="login loginmodal-submit" style="width:30%; max-width:90%;margin: 0 auto; margin-top:10px;" value="<?php echo _lng('Add'); ?>" >
				<input type="hidden" name="view" value="home">
				<input type="hidden" name="task" value="add">
			  </form>
			</div>
		</div>
	</div>
</div>

