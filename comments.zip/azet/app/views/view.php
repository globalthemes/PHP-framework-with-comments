<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 //prevent direct access
 defined('_EXEC') or die;
 
class BaseView {

	protected $data;
	protected $layout;

	/**
	 * Constructor
	 *
	 * @since	1.0.1
	 */
	public function __construct($data, $layout='home_public'){

		$this->data = $data;
		$this->layout = $layout;		
	
	}	

	public function Render () {
		
		loadLayout($this->layout, $this->data);

	}
}	
?>

