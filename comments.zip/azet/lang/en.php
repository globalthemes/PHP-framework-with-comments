<?php
/**
 * @version		1.0.1
 * @date 		08.06.2016
 * @package		AZET test
 * @author		Ing. Zoltán Köböl
 * @copyright	Copyright (C) 2014 - 2016 Open Source Matters, Inc. All rights reserved. 
 * @license     GNU General Public License version 2 or later; see LICENSE
 */
 
 
 //prevent direct access
 defined('_EXEC') or die;
 
 $language = array (
 
	'Home' => 'Home',
	'Login' => 'Log In',
	'Signup' => 'Sign Up',
	'Default home site' => 'Default home site',
	'Non Administrator User can access' => '(User can access)',
	'Public access' => '(Public access)',
	'Only Administrator can access' => '(Administrator can access)',
	'Login to Your Account' => 'Login to Your Account',
	'Username' => 'Username',
	'Password' => 'Password',
	'Password confirm' => 'Confirm your password',
	'Login' => 'Login',
	'Required' => 'This field cannot be empty!',
	'Error loading MVC model class for view:' => 'Error loading MVC model class for view:',
	'Error loading MVC view class for view:' => 'Error loading MVC view class for view:',
	'Username or Password is incorrect, you are not logged in!' => 'Username or Password is incorrect, you are not logged in!',
	'User successfuly registered. Please login with your credentials.' => 'User successfuly registered. Please login with your credentials.',
	'User with name ' => 'User with name \'',
	'already exists!' => '\'already exists!',
	'Password ERROR! Entered passwords are not identical!' => 'Password ERROR! Entered passwords are not identical!',
	'Password ERROR! You can use only letters and digits!' => 'Password ERROR! You can use only letters and digits!',
	'Password ERROR! Password must be at least 8 characters!' => 'Password ERROR! Password must be at least 8 characters!',
	'Username ERROR! Username must be at least 4 characters!' => 'Username ERROR! Username must be at least 4 characters!',
	'' => '',			
 );


?>

